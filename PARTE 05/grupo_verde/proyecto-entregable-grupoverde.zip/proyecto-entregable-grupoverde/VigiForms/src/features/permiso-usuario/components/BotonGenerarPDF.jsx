import React from 'react'

export const BotonGenerarPDF = () => {
  return (
    <>
        <button className='rounded bg-green-800 text-white px-3 py-2 shadow shadow-green-900 w-40 mt-4 font-semibold'>Generar PDF</button>
    </>
  )
}
