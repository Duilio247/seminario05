# Interfaz de Login en Kotlin

Agregar una conexion a la api de gandy

### Amarillo
* Juan Piero
* Dulio Quispe

## 📱 Capturas de pantalla

![estudiante](https://raw.githubusercontent.com/juanitoeldesastre/LoginUI/main/captures/login_estudiante.PNG)
![welcome](https://raw.githubusercontent.com/juanitoeldesastre/LoginUI/main/captures/welcome.PNG)
![vigilante](https://raw.githubusercontent.com/juanitoeldesastre/LoginUI/main/captures/login_vigilante.PNG)

## 🛠️Tecnologías

- **Kotlin**
- **Jetpack Compose**
- **Android Studio**
- **Material 3**

## 🚧 En Construccion
