export * from "./PaginaRegistroInstructor";
export * from "./PaginaHistorialDocentes";


