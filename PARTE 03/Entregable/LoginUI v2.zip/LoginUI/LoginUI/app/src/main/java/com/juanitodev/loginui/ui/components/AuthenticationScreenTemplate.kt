package com.juanitodev.loginui.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AuthenticationScreenTemplate(
    modifier: Modifier = Modifier,
    backgroundGradient: Array<Pair<Float, Color>>,
    imgRes: Int,
    title: String,
    subtitle: String,
    mainActionButtonTitle: String,
    secondaryActionButtonTitle: String,
    mainActionButtonColors: ButtonColors,
    secondaryActionButtonColors: ButtonColors,
    actionButtonShadow: Color,
    onMainActionButtonClicked: () -> Unit,
    onSecondaryActionButtonClicked: () -> Unit,
    content: @Composable () -> Unit = {} // 👈 Para campos dinámicos
) {
    val gradientBrush = Brush.verticalGradient(colorStops = backgroundGradient)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(brush = gradientBrush)
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Image(
                    painter = painterResource(id = imgRes),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .height(180.dp)
                        .padding(top = 24.dp)
                )

                Spacer(modifier = Modifier.height(24.dp))

                Text(text = title, style = MaterialTheme.typography.headlineSmall)
                Text(text = subtitle, fontSize = 16.sp)

                Spacer(modifier = Modifier.height(16.dp))

                content() // 👈 Aquí se renderizan los TextFields, etc.
            }

            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                ActionButton(
                    text = mainActionButtonTitle,
                    isNavigationArrowVisible = true,
                    onClicked = onMainActionButtonClicked,
                    colors = mainActionButtonColors,
                    shadowColor = actionButtonShadow
                )

                ActionButton(
                    text = secondaryActionButtonTitle,
                    isNavigationArrowVisible = false,
                    onClicked = onSecondaryActionButtonClicked,
                    colors = secondaryActionButtonColors,
                    shadowColor = actionButtonShadow
                )
            }
        }
    }
}
