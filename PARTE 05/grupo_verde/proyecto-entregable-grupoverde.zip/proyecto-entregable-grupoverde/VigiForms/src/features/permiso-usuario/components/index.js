export * from "./MostrarFormularioPermiso"
export * from "./BotonGenerarPDF"


export * from "./BotonHistorial"
export * from "./PermisoDocenteRow"

export * from "./PDF"

export * from "./editarPermiso"
