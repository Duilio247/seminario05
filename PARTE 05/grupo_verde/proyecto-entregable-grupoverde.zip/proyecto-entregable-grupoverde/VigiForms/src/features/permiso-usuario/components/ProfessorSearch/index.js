import ProfessorSearch from './ProfessorSearch';
export default ProfessorSearch;