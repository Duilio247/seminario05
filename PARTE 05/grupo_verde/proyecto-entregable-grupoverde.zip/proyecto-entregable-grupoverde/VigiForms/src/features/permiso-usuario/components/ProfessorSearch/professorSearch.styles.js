export const containerStyles = {
  maxWidth: '500px',
};

export const selectedProfessorStyles = {
  marginTop: '20px'
};