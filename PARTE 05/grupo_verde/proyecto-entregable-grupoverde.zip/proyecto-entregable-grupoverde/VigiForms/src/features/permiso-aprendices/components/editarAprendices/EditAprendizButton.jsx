import { useNavigate } from "react-router-dom";
import { toast } from 'sonner';

export const EditButton = ({ data }) => {
  const navigate = useNavigate();

  const handleEditClick = () => {
    console.log("Datos recibidos para editar:", data);

    if (!data) {
      toast.error("No hay datos para editar");
      return;
    }

    navigate(`/editar-aprendiz/${data.id}`, {
      state: { permisoData: data }
    });
  };

  return (
    <button
      onClick={handleEditClick}
      className="px-3 py-1 bg-yellow-500 text-white rounded hover:bg-yellow-600"
    >
      Editar
    </button>
  );
};
