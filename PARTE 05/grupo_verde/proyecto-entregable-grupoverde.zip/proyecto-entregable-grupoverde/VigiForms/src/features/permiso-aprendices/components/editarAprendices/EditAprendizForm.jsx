import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { toast } from 'sonner';

export const EditAprendizForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const [isLoading, setIsLoading] = useState(true);
  const [initialData, setInitialData] = useState(null);

  const { register, handleSubmit, formState: { errors }, reset } = useForm();

  // Carga inicial
  useEffect(() => {
    if (location.state?.permisoData) {
      setInitialData(location.state.permisoData);
      setFormValues(location.state.permisoData);
      setIsLoading(false);
    } else {
      fetchPermisoData();
    }
  }, [id, location]);

  const fetchPermisoData = async () => {
    try {
      const res = await fetch(`http://localhost:3000/api/permisos-aprendices/${id}`);
      if (!res.ok) throw new Error('Error al cargar datos');
      const data = await res.json();
      setInitialData(data);
      setFormValues(data);
      setIsLoading(false);
    } catch (e) {
      toast.error(e.message);
      navigate(-1);
    }
  };

  // Precarga solo los 3 campos
  const setFormValues = (data) => {
    reset({
      nombres: data.nombres || '',
      apellidos: data.apellidos || '',
      motivo: data.motivo || ''
    });
  };

  // Envío de edición
  const onSubmit = async (formData) => {
    try {
      const loading = toast.loading('Actualizando permiso...');
      const payload = {
        nombres: formData.nombres,
        apellidos: formData.apellidos,
        motivo: formData.motivo
      };
      console.log('Enviando payload:', payload);

      const res = await fetch(`http://localhost:3000/api/permisos-aprendices/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const body = await res.json();
      console.log('Respuesta:', res.status, body);

      toast.dismiss(loading);
      if (!res.ok) throw new Error(body.message || 'Error al actualizar permiso');
      toast.success('Permiso actualizado correctamente');
      navigate('/historialAprendices');
    } catch (e) {
      console.error('Error en onSubmit:', e);
      toast.error(e.message);
    }
  };

  if (isLoading) return <div className="text-center py-8">Cargando...</div>;

  return (
    <div className="max-w-xl mx-auto p-4 bg-white rounded-lg shadow-md mt-20">
      <h2 className="text-2xl font-bold mb-6 text-center">Editar Datos del Aprendiz</h2>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        {/* Nombres */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Nombres</label>
          <input
            {...register("nombres", { required: "Este campo es requerido" })}
            type="text"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          {errors.nombres && (
            <p className="text-red-500 text-sm mt-1">{errors.nombres.message}</p>
          )}
        </div>

        {/* Apellidos */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Apellidos</label>
          <input
            {...register("apellidos", { required: "Este campo es requerido" })}
            type="text"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          {errors.apellidos && (
            <p className="text-red-500 text-sm mt-1">{errors.apellidos.message}</p>
          )}
        </div>

        {/* Motivo */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Motivo</label>
          <textarea
            {...register("motivo", { required: "Este campo es requerido" })}
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          {errors.motivo && (
            <p className="text-red-500 text-sm mt-1">{errors.motivo.message}</p>
          )}
        </div>

        {/* Botones */}
        <div className="flex justify-end space-x-3 pt-4">
          <button
            type="button"
            onClick={() => navigate(-1)}
            className="px-4 py-2 bg-gray-300 text-gray-800 rounded-md hover:bg-gray-400"
          >
            Cancelar
          </button>
          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Guardar Cambios
          </button>
        </div>
      </form>
    </div>
  );
};
