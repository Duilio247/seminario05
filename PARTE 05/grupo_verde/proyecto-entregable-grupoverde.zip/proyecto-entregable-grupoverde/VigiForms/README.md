# FRONTEND EQUIPO VERDE

## ✅ Formularios Permisos
**Formulario Permisos Aprendizajes:**
Ejemplo de uso para registrar en el formulario aprendices un crud (Anular, GuardarPDF, Editar y Desanular) con filtrado y busqueda de datos del backend.

![captura1](img/permisos-aprendices.png)

