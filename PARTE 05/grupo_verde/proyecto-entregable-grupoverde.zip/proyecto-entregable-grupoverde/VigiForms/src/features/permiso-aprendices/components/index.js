export * from "./MostrarFormularioAprendices"
export * from "./BtnGenerarPDF"
export { default as PermisoAprendicesRow } from './PermisoAprendicesRow.jsx';
export * from "./HistorialA"
export * from "./PermisoAprendicesRow"

export * from "./PDF"

// export * from "./editarPermiso"




