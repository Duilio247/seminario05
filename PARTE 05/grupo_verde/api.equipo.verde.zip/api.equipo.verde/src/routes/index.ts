export { default as encargadoRoutes } from './encargado.routes';
export { default as instructorRoutes } from './instructor.routes';
export { default as permisoInstructorRoutes } from './permiso-instructor.routes';
export { default as permisoMaterialRoutes } from './permiso-material.routes';
export { default as permisoAprendizRoutes } from './permiso-aprendiz.routes';