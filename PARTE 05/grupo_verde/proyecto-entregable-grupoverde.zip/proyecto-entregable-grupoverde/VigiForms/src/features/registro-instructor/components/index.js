export * from "./MostrarRegistroInstructor";
export * from "./HistorialDocentes";
export * from "./HistorialDocenteRow";
