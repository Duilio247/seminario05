export * from './PaginaFormularioAprendices'
export * from './PaginaHistorialAprendices'
