import React from 'react'

export const BtnGenerarPDF = () => {
  return (
    <>
        <button className='rounded bg-green-800 text-white px-3 py-2 shadow shadow-green-900 w-40 mt-4 font-semibold mb-2'>Generar PDF</button>
    </>
  )
}
