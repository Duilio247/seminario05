import React from "react";

export const GenerarPDF = () => {
  return (
    <>
        <button className='rounded bg-red-800 text-white px-3 py-2 shadow shadow-green-900 w-40 mt-4 font-semibold'>Generar PDF</button>
    </>
  )
}